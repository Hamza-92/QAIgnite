
{{-- <div class="ml-1 grid flex-1 text-left text-sm">
    <span class="mb-0.5 truncate leading-none font-bold text-xl">QA Ignite</span>
</div> --}}

<div class="px-4 py-2 ">
    <span class="text-2xl font-bold text-accent">QA Ignite</span>
</div>
