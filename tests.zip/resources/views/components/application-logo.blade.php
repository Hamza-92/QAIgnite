<img class="w-32" src="{{asset('storage/images/logo/qaignite-logo.png')}}" alt="">
