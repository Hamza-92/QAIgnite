<x-layouts.app.main>
    <main>
        {{ $slot }}
    </main>
</x-layouts.app.main>
