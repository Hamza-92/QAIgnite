<div class="flex flex-col gap-1 w-full <?php echo e($class); ?>">
    <label><?php echo e($label); ?>

        <?php if($required): ?>
            <span class="text-red-500">*</span>
        <?php endif; ?>
    </label>
    <input wire:model='<?php echo e($model); ?>' type="<?php echo e($type); ?>" name="<?php echo e($model); ?>" id="<?php echo e($model); ?>"
        placeholder="<?php echo e($placeholder); ?>" class="px-4 py-2 rounded-md border border-gray-200 dark:border-gray-700">
    <?php $__errorArgs = [$model];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-red-500"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views\components\input-field.blade.php ENDPATH**/ ?>