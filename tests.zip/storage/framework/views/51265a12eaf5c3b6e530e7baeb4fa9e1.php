<div class="flex flex-col gap-2 w-full <?php echo e($class); ?>" $attributes>
    <label>
        <?php echo e($label); ?>

        <?php if($required): ?>
            <span class="text-red-500">*</span>
        <?php endif; ?>
    </label>

    <div x-data='{open_model : false}' @click.outside="open_model = false" @close.stop="open_model = false"
        class="relative">

        
        <div @click="open_model = !open_model" class="flex items-center px-4 py-2 rounded-md border border-gray-200 dark:border-gray-700">

            <div class="w-full flex items-center justify-between">
                <span>
                    <?php echo e($selected_option); ?>

                </span>
                <button x-show="<?php echo e($selected_option ? 'true' : 'false'); ?>" @click="open_model = false" class="px-1" type="button">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            <i :class="{ 'fa-angle-down': !open_model, 'fa-angle-up': open_model }"
                class="fa-solid ml-2 text-gray-500"></i>
        </div>

        
        <div x-show='open_model' x-transition:enter="transition ease-out duration-200"
            x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100"
            x-transition:leave="transition ease-in duration-75" x-transition:leave-start="opacity-100 scale-100"
            x-transition:leave-end="opacity-0 scale-95"
            class="absolute z-10 mt-2 w-full rounded-md shadow-lg bg-gray-100 dark:bg-gray-800 max-h-72 overflow-auto">
            <div class="border-b dark:border-gray-700">
                <input wire:model.live.debounce.300='<?php echo e($search); ?>' type="text"
                    class="w-full px-4 py-3 text-sm dark:bg-gray-800 outline-none focus:outline-none border-none focus:border-none focus:ring-none"
                    placeholder="Type to search">
            </div>
            <div>
                <?php $__empty_1 = true; $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <button wire:key='<?php echo e($option->id); ?>' id="<?php echo e($option->id); ?>" type="button"
                        <?php echo e($option_attributes); ?> @click = 'open_model = false'
                        class="py-3 px-4 bg-white dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-left w-full">
                        <?php echo e($option->name); ?>

                        
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p
                        class="py-3 px-4 bg-white dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-left w-full">
                        No records found</p>
                <?php endif; ?>
            </div>
        </div>

        
        <?php $__errorArgs = [$model];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-red-500"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views\components\searchable-select.blade.php ENDPATH**/ ?>