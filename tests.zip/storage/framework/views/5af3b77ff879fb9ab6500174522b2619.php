<div x-data="{ open: false }"
    class="relative flex flex-1 items-center justify-between <?php echo e($class); ?>">
    <div class="" @click.outside="open = false" @close.stop="open = false">
        <div @click="open = !open; if(open) $wire.refreshList();"
            class="flex items-center justify-between gap-4 bg-blue-100 dark:bg-blue-900/50 rounded-xl px-4 py-2 w-72">
            <p>Project:
                <span class="font-medium">
                    <?php if(isset($project)): ?>
                        <?php echo e($project->name); ?>

                    <?php else: ?>
                        Select a Project
                    <?php endif; ?>
                </span>
            </p>
            <i class="fa-solid fa-caret-down"></i>
        </div>
        <div x-show="open" x-transition:enter="transition ease-out duration-200"
            x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100"
            x-transition:leave="transition ease-in duration-75" x-transition:leave-start="opacity-100 scale-100"
            x-transition:leave-end="opacity-0 scale-95"
            class="absolute z-50 mt-2 w-72 shadow-lg dark:bg-gray-800 max-h-80 overflow-auto">
            <div class="border-b dark:border-gray-700">
                <input wire:model.live.debounce.300='search' type="text" name="search"
                    class="w-full px-4 py-3 text-sm bg-white dark:bg-gray-800 outline-none focus:outline-none border-none focus:border-none focus:ring-none"
                    placeholder="Type to search">
            </div>
            <div>
                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <button id="<?php echo e($project->id); ?>" wire:click='setProject(<?php echo e($project->id); ?>)'
                        class="flex items-center justify-between py-3 px-4 bg-white dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-left w-full">
                        <?php echo e($project->name); ?>

                        <?php if($project->id == auth()->user()->default_project): ?>
                            <i class="fa-solid fa-check text-green-500"></i>
                        <?php endif; ?>
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p
                        class="py-3 px-4 bg-white dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-left w-full">
                        No project found</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views\livewire\components\project-selector.blade.php ENDPATH**/ ?>