<div>
    <div class="px-8 py-4 flex gap-4 flex-wrap items-center justify-between border-b border-gray-200 dark:border-gray-700">
        <h2 class="text-2xl">Role Management</h2>
        <a href="<?php echo e(route('role.create')); ?>" wire:navigate
            class="px-4 py-2 bg-blue-500 dark:bg-blue-600 text-white hover:bg-blue-600 dark:hover:bg-blue-500 rounded-md cursor-pointer">Create
            Role</a>
    </div>

    
    <div class="px-4 md:px-8 py-4">
        <div class="flex flex-wrap gap-4 items-center justify-between">
            
            <?php if (isset($component)) { $__componentOriginal52aeb1f981ab196666a9afcb1710a1a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1 = $attributes; } ?>
<?php $component = App\View\Components\TableEntries::resolve(['entries' => 'perPage'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table-entries'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\TableEntries::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1)): ?>
<?php $attributes = $__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1; ?>
<?php unset($__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52aeb1f981ab196666a9afcb1710a1a1)): ?>
<?php $component = $__componentOriginal52aeb1f981ab196666a9afcb1710a1a1; ?>
<?php unset($__componentOriginal52aeb1f981ab196666a9afcb1710a1a1); ?>
<?php endif; ?>

            
            <div class="flex items-center gap-4">
                <?php if (isset($component)) { $__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d = $attributes; } ?>
<?php $component = App\View\Components\SearchField::resolve(['search' => 'search','placeholder' => 'Search...','resetMethod' => 'resetSearch'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('search-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SearchField::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d)): ?>
<?php $attributes = $__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d; ?>
<?php unset($__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d)): ?>
<?php $component = $__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d; ?>
<?php unset($__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d); ?>
<?php endif; ?>
            </div>
        </div>
        <div class="mt-4 border border-gray-200 dark:border-gray-700 overflow-x-auto">
            <table class="w-full border-collapse text-sm ">
                <thead class="bg-gray-200 dark:bg-gray-700 font-medium">
                    <tr>
                        <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'name','displayName' => 'Role Name','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','displayName' => 'Role Name','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'description','displayName' => 'Description','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'description','displayName' => 'Description','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'users','displayName' => 'Users','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'users','displayName' => 'Users','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        <th class="px-4 py-3 font-medium text-left">Deletable</th>
                        <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'created_at','displayName' => 'Created Date','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'created_at','displayName' => 'Created Date','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        <th class="px-4 py-3 font-medium">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr wire:key='<?php echo e($role->id); ?>' class="hover:bg-gray-100 dark:hover:bg-gray-800">
                            <td class="px-4 py-3"><?php echo e($role->name); ?></td>
                            <td class="px-4 py-3"><?php echo e($role->description); ?></td>
                            <td class="px-4 py-3"><?php echo e($role->users_count); ?></td>
                            <td class="px-4 py-3">
                                <span
                                    class="<?php echo e($role->deletable ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'); ?> px-2 py-1 rounded">
                                    <?php echo e($role->deletable ? 'True' : 'False'); ?>

                                </span>
                            </td>
                            <td class="px-4 py-3"><?php echo e($role->created_at); ?></td>
                            <td class="flex items-center justify-center text-center px-4 py-3">
                                <?php if(!$role->default): ?>
                                    <a href="<?php echo e(route('role.edit', ['id' => $role->id])); ?>"
                                        class="px-1 py-1 cursor-pointer hover:text-blue-500" type="button"
                                        wire:navigate>
                                        <?php if (isset($component)) { $__componentOriginalb255e21fe9b8d1d1a0ccae43c506ad59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb255e21fe9b8d1d1a0ccae43c506ad59 = $attributes; } ?>
<?php $component = App\View\Components\Tooltip::resolve(['message' => 'Edit Role'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tooltip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Tooltip::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                            <i class="fa-solid fa-pen-to-square"></i>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb255e21fe9b8d1d1a0ccae43c506ad59)): ?>
<?php $attributes = $__attributesOriginalb255e21fe9b8d1d1a0ccae43c506ad59; ?>
<?php unset($__attributesOriginalb255e21fe9b8d1d1a0ccae43c506ad59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb255e21fe9b8d1d1a0ccae43c506ad59)): ?>
<?php $component = $__componentOriginalb255e21fe9b8d1d1a0ccae43c506ad59; ?>
<?php unset($__componentOriginalb255e21fe9b8d1d1a0ccae43c506ad59); ?>
<?php endif; ?>
                                    </a>
                                    <?php if($role->deletable): ?>
                                        <?php if (isset($component)) { $__componentOriginalbd5922df145d522b37bf664b524be380 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbd5922df145d522b37bf664b524be380 = $attributes; } ?>
<?php $component = App\View\Components\ConfirmationModal::resolve(['method' => 'deleteRole','param' => ''.e($role->id).'','type' => 'delete','title' => 'Delete Role','message' => 'Are you sure you want to delete the role? Remember this action cannot be undone.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ConfirmationModal::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                            <button class="px-1 py-1 text-red-500" type="button">
                                                <?php if (isset($component)) { $__componentOriginalb255e21fe9b8d1d1a0ccae43c506ad59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb255e21fe9b8d1d1a0ccae43c506ad59 = $attributes; } ?>
<?php $component = App\View\Components\Tooltip::resolve(['message' => 'Delete Role'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tooltip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Tooltip::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                                    <i class="fa-solid fa-trash"></i>
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb255e21fe9b8d1d1a0ccae43c506ad59)): ?>
<?php $attributes = $__attributesOriginalb255e21fe9b8d1d1a0ccae43c506ad59; ?>
<?php unset($__attributesOriginalb255e21fe9b8d1d1a0ccae43c506ad59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb255e21fe9b8d1d1a0ccae43c506ad59)): ?>
<?php $component = $__componentOriginalb255e21fe9b8d1d1a0ccae43c506ad59; ?>
<?php unset($__componentOriginalb255e21fe9b8d1d1a0ccae43c506ad59); ?>
<?php endif; ?>
                                            </button>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbd5922df145d522b37bf664b524be380)): ?>
<?php $attributes = $__attributesOriginalbd5922df145d522b37bf664b524be380; ?>
<?php unset($__attributesOriginalbd5922df145d522b37bf664b524be380); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbd5922df145d522b37bf664b524be380)): ?>
<?php $component = $__componentOriginalbd5922df145d522b37bf664b524be380; ?>
<?php unset($__componentOriginalbd5922df145d522b37bf664b524be380); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span>-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="w-full p-4 text-center" colspan="5">No Records found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-4"><?php echo e($roles->links()); ?></div>
    </div>
</div><?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views\livewire\role\roles.blade.php ENDPATH**/ ?>