<div class="bg-white dark:bg-gray-800 shadow rounded-lg">
    <div class="flex items-center justify-between gap-4 p-4 border-b border-gray-200 dark:border-gray-700">
        <h3>Test Scenarios</h3>
        <button type="button">
            <i class="fa-solid fa-filter"></i>
        </button>
    </div>
    <div>

    </div>
</div><?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views\livewire/components/dashboard/info-card/test-scenario.blade.php ENDPATH**/ ?>