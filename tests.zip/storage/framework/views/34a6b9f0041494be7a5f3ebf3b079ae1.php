<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Report PDF</title>
    <style>
        body {
            font-family: sans-serif;
            padding: 20px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .table td {
            border: 1px solid #e5e7eb; /* Tailwind gray-200 */
            padding: 8px 12px;
        }
        .header-cell {
            background-color: #f3f4f6; /* Tailwind gray-100 */
            font-weight: bold;
            width: 30%;
        }
    </style>
</head>
<body class="p-10">
    <h2 class="text-xl font-bold"><?php echo e($report_title); ?></h2>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <table class="w-full border-collapse text-sm">
            <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-4 py-3 font-medium text-left bg-gray-100 w-[30%]"><?php echo e($header); ?></td>
                    <td class="px-12 py-8 border border-gray-200"><?php echo e($row[$index] ?? ''); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views/reports/pdf-downloader/defect-report.blade.php ENDPATH**/ ?>