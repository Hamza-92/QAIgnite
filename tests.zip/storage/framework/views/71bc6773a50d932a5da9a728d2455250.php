<div>
    <div class="flex items-center justify-between flex-wrap gap-4 px-8 py-4 border-b dark:border-gray-700">
        <div class="flex flex-col items-start">
            <a href="<?php echo e(route('test-case-execution.list', [$test_cycle_id])); ?>" wire:navigate
                class="text-blue-500 py-1 rounded-md space-x-2"><i class="fa-solid fa-arrow-left"></i> Test Cycle</a>
            <h2 class="text-lg font-medium mt-2">Test Case Execution</h2>
        </div>
    </div>
    
    <div class="px-8 py-4 w-full mb-8">
        
        <div class="border dark:border-gray-700 mt-4 overflow-x-auto">
            <table>
                
                <tr class="border-b dark:border-gray-700">
                    <th
                        class="px-4 py-3 border-r sm:whitespace-nowrap dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                        Test Case Creation Date
                    </th>
                    <td class="w-full px-4 py-3"><?php echo e($test_case->created_at->format('d-m-Y H:i:s') ?? ''); ?></td>
                </tr>
                
                <tr class="border-b dark:border-gray-700">
                    <th
                        class="px-4 py-3 border-r dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                        Test Case ID
                    </th>
                    <td class="w-full px-4 py-3">
                        <a class="underline hover:text-blue-500"
                            href="<?php echo e(route('test-case.detail', [$test_case->id])); ?>" target="_blank" wire:navigate>
                            <?php echo e($test_case->tc_name ?? ''); ?>

                        </a>
                    </td>
                </tr>
                
                <tr class="border-b dark:border-gray-700">
                    <th
                        class="px-4 py-3 border-r dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                        Testing Type
                    </th>
                    <td class="w-full px-4 py-3"><?php echo e(ucfirst($test_case->tc_testing_type) ?? ''); ?></td>
                </tr>
                
                <tr class="border-b dark:border-gray-700">
                    <th
                        class="px-4 py-3 border-r dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                        Execution Type
                    </th>
                    <td class="w-full px-4 py-3"><?php echo e(ucfirst($test_case->tc_execution_type) ?? ''); ?></td>
                </tr>
                
                <tr class="border-b dark:border-gray-700">
                    <th
                        class="px-4 py-3 border-r dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                        Priority
                    </th>
                    <td class="w-full px-4 py-3">
                        <?php if($test_case->tc_priority === 'high'): ?>
                            <span class="text-red-500"><?php echo e($test_case->tc_priority); ?></span>
                        <?php elseif($test_case->tc_priority === 'medium'): ?>
                            <span class="text-yellow-500"><?php echo e($test_case->tc_priority); ?></span>
                        <?php elseif($test_case->tc_priority === 'low'): ?>
                            <span class="text-green-500"><?php echo e($test_case->tc_priority); ?></span>
                        <?php else: ?>
                            <span><?php echo e($test_case->tc_priority); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
                
                <tr class="border-b dark:border-gray-700">
                    <th
                        class="px-4 py-3 border-r dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                        Summary
                    </th>
                    <td class="w-full px-4 py-3"><?php echo e($test_case->tc_description ?? ''); ?></td>
                </tr>
                
                <tr class="border-b dark:border-gray-700">
                    <th
                        class="px-4 py-3 border-r dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                        Assign To
                    </th>
                    <td class="w-full px-4 py-3"><?php echo e($test_case->assigned_to->username ?? ''); ?></td>
                </tr>
                
                <tr class="border-b dark:border-gray-700">
                    <th
                        class="px-4 py-3 border-r dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                        Pre Conditions
                    </th>
                    <td class="w-full px-4 py-3">
                        <?php echo e($test_case->tc_preconditions ?? ''); ?>

                    </td>
                </tr>
                
                <tr class="border-b dark:border-gray-700">
                    <th
                        class="px-4 py-3 border-r dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                        Detailed Steps
                    </th>
                    <td class="w-full px-4 py-3">
                        <?php echo e($test_case->tc_detailed_steps ?? ''); ?>

                    </td>
                </tr>
                
                <tr class="border-b dark:border-gray-700">
                    <th
                        class="px-4 py-3 border-r dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                        Expected Result
                    </th>
                    <td class="w-full px-4 py-3">
                        <?php echo e($test_case->tc_expected_results ?? ''); ?>

                    </td>
                </tr>
                
                <tr class="border-b dark:border-gray-700">
                    <th
                        class="px-4 py-3 border-r dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                        Post Conditions
                    </th>
                    <td class="w-full px-4 py-3">
                        <?php echo e($test_case->tc_post_conditions ?? ''); ?>

                    </td>
                </tr>
                
                <tr>
                    <th
                        class="px-4 py-3 border-r dark:border-gray-700 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                        Estimate Time
                    </th>
                    <td class="w-full px-4 py-3">
                        <?php
                            $hours = intdiv($test_case->tc_estimated_time ?? 0, 60);
                            $minutes = ($test_case->tc_estimated_time ?? 0) % 60;
                        ?>
                        <?php echo e($hours); ?>h <?php echo e($minutes); ?>m
                    </td>
                </tr>
            </table>
        </div>

        
        <div x-data="{ open_model: true }" class="w-full mt-8">
            <div @click="open_model = !open_model"
                class="w-full flex items-center justify-between px-4 py-2 cursor-pointer text-white bg-blue-500 hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-500 transition-colors duration-300 rounded-t-lg"
                :class="{ 'rounded-lg': !open_model }">
                <h3 class="text-lg font-medium">Executions</h3>
                <span class="px-2 py-1 bg-white text-gray-900 font-bold rounded transition-transform duration-300"
                    :class="{ 'rotate-180': open_model }" x-text="open_model ? '−' : '+'"></span>
            </div>

            <div x-show="open_model" x-collapse.duration.300ms class="flex flex-col gap-3 overflow-x-auto"
                x-transition:enter="transition ease-out duration-300"
                x-transition:enter-start="opacity-0 transform scale-95"
                x-transition:enter-end="opacity-100 transform scale-100"
                x-transition:leave="transition ease-in duration-200"
                x-transition:leave-start="opacity-100 transform scale-100"
                x-transition:leave-end="opacity-0 transform scale-95">
                <table class="mt-2 border dark:border-gray-700">
                    <thead>
                        <tr>
                            <th class="px-4 py-3 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                                Date
                            </th>
                            <th class="px-4 py-3 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                                Comments
                            </th>
                            <th class="px-4 py-3 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                                Tested By
                            </th>
                            <th class="px-4 py-3 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                                Status
                            </th>
                            <th class="px-4 py-3 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                                Defect ID
                            </th>
                            <th class="px-4 py-3 bg-gray-100 dark:bg-gray-800 text-left font-medium">
                                Time
                            </th>
                            <th class="px-4 py-3 bg-gray-100 dark:bg-gray-800 font-medium">
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $test_case_executions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $execution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-100 dark:hover:bg-gray-700">
                                <td class="px-4 py-3">
                                    <?php echo e($execution->created_at); ?>

                                </td>
                                <td class="px-4 py-3">
                                    <?php echo e($execution->comment); ?>

                                </td>
                                <td class="px-4 py-3">
                                    <?php echo e($execution->executedBy->username); ?>

                                </td>
                                <td class="px-4 py-3">
                                    <?php
                                        $statusClasses = [
                                            'Passed' => 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-200',
                                            'Failed' => 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-200',
                                            'Not Executed' => 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-200',
                                        ];
                                    ?>

                                    <span class="px-3 py-1 rounded-full <?php echo e($statusClasses[$execution->status] ?? 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300'); ?>">
                                        <?php echo e($execution->status); ?>

                                    </span>
                                </td>

                                <td class="px-4 py-3">
                                    <?php echo e($execution->defect->def_name ?? ''); ?>

                                </td>
                                <td class="px-4 py-3">
                                    <?php echo e(gmdate('H:i:s', $execution->execution_time)); ?>

                                </td>
                                <td class="px-4 py-3 flex items-center gap-2 justify-center">
                                    <?php if($execution->status == 'Failed' && ! $execution->defect_id): ?>
                                        <a href="<?php echo e(route('defects')); ?>" wire:navigate class="px-2 py-1 rounded-md border dark:border-gray-600 space-x-2 text-red-500 hover:bg-red-500 hover:text-white transition-colors duration-300ms">
                                            <i class="fa-solid fa-bug"></i> Add Defect
                                        </a>
                                    <?php endif; ?>
                                    <div class="relative" x-data="{ open: false }">
                                        <button type="button" @click="open = !open"
                                            class="px-3 py-1 rounded-md bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-900 dark:text-gray-100 cursor-pointer transition-colors"
                                            aria-label="Actions menu">
                                            <i class="fa-solid fa-ellipsis-vertical"></i>
                                        </button>
                                        <div x-show="open" @click.outside="open = false" x-transition
                                            class="absolute divide-x divide-gray-200 dark:divide-gray-700 top-1/2 right-full mr-3 transform -translate-y-1/2 p-1 text-md bg-white dark:bg-gray-800 rounded-md border dark:border-gray-700 shadow-lg z-10 flex items-center justify-center before:absolute before:top-1/2 before:left-full before:-translate-y-1/2 before:w-0 before:h-0 before:border-[6px] before:border-t-transparent before:border-b-transparent before:border-l-white dark:before:border-l-gray-800 before:border-r-transparent">
                                            <!-- Attach Files -->
                                            <button type="button" title="Attach Files"
                                                class="px-3 py-1 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 transition-colors cursor-pointer">
                                                <i class="fa-solid fa-paperclip"></i>
                                            </button>
                                            <!-- View Attached Files Button -->
                                            <button type="button" title="View Attached Files"
                                                class="px-3 py-1 text-green-600 hover:text-green-800 dark:text-green-400 dark:hover:text-green-300 transition-colors cursor-pointer">
                                                <i class="fa-solid fa-folder-open"></i>
                                            </button>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div>
            
            <form wire:submit.prevent='save' class="space-y-4">
                <div class="mt-8 px-8 py-4 bg-gray-100 dark:bg-gray-800 border dark:border-gray-700">
                    <h3 class="text-blue-500 text-2xl font-medium">Test Case Execution Time</h3>
                    <div class="flex items-center gap-4 py-4" wire:poll.1s>
                        
                        <div
                            class="px-8 py-2 bg-white dark:bg-gray-900 shadow-sm rounded-md text-3xl font-mono tracking-tighter inline-flex items-center gap-4">
                            <i class="fa-solid fa-stopwatch mr-2 text-gray-500"></i>
                            <span class="text-gray-800 dark:text-gray-200"><?php echo e($formatted_time); ?></span>
                        </div>
                        
                        <?php if(!$is_running && !$executionSession->started_at): ?>
                            <button wire:click="start" type="button"
                                class="px-4 py-2 text-2xl bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 text-white rounded w-36 text-center">Start</button>
                        <?php elseif($is_running): ?>
                            <button wire:click="pause" type="button"
                                class="px-4 py-2 text-2xl bg-yellow-500 text-white rounded hover:bg-yellow-600 w-36 text-center">Pause</button>
                        <?php else: ?>
                            <button wire:click="resume" type="button"
                                class="px-4 py-2 text-2xl bg-green-600 text-white rounded hover:bg-green-700 w-36 text-center">Resume</button>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Status','model' => 'status','required' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <option value="select">Select</option>
                    <option value="Passed">Passed</option>
                    <option value="Failed">Failed</option>
                    <option value="Not Executed">Not Executed</option>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                
                <?php if (isset($component)) { $__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb = $attributes; } ?>
<?php $component = App\View\Components\Textarea::resolve(['label' => 'Comment','model' => 'comment','rows' => '5'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Textarea::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb)): ?>
<?php $attributes = $__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb; ?>
<?php unset($__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb)): ?>
<?php $component = $__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb; ?>
<?php unset($__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb); ?>
<?php endif; ?>

                <div class="py-16 flex items-center justify-center gap-4">
                    <button type="submit"
                        class="px-6 py-2 w-48 bg-blue-500 hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-500 text-white text-2xl text-center cursor-pointer rounded-md">
                        Execute <i wire:loading wire:target='save' class="fa-solid fa-spinner fa-spin"></i>
                    </button>
                    <a href="<?php echo e(route('test-case-execution.list', [$test_cycle_id])); ?>" wire:navigate
                        class="px-6 py-2 w-48 bg-gray-200 hover:bg-gray-300 dark:bg-gray-800 dark:hover:bg-gray-700 text-2xl text-center cursor-pointer rounded-md">
                        Back
                    </a>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views\livewire\test-case-execution\execute-test-case.blade.php ENDPATH**/ ?>