<div x-data = "{confirmationModel : false, moduleid : null}" class="w-full h-full">

    
    <div class="px-8 py-4 flex-wrap gap-2 flex items-center justify-between border-b border-gray-200 dark:border-gray-700">
        <h2 class="text-2xl">Modules Management</h2>
        <button x-on:click="$wire.createModule = true"
            class="px-4 py-2 bg-blue-500 hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-500 text-white rounded-md cursor-pointer"
            type="button">Create Module</button>
    </div>

    
    <div class="px-8 py-4">
        <div class="flex flex-wrap gap-2 items-center justify-between">
            <?php if (isset($component)) { $__componentOriginal52aeb1f981ab196666a9afcb1710a1a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1 = $attributes; } ?>
<?php $component = App\View\Components\TableEntries::resolve(['entries' => 'perPage'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table-entries'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\TableEntries::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1)): ?>
<?php $attributes = $__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1; ?>
<?php unset($__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52aeb1f981ab196666a9afcb1710a1a1)): ?>
<?php $component = $__componentOriginal52aeb1f981ab196666a9afcb1710a1a1; ?>
<?php unset($__componentOriginal52aeb1f981ab196666a9afcb1710a1a1); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d = $attributes; } ?>
<?php $component = App\View\Components\SearchField::resolve(['search' => 'search','resetMethod' => 'resetSearch'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('search-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SearchField::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d)): ?>
<?php $attributes = $__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d; ?>
<?php unset($__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d)): ?>
<?php $component = $__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d; ?>
<?php unset($__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d); ?>
<?php endif; ?>
        </div>
        <div class="mt-4 border border-gray-200 dark:border-gray-700 overflow-x-auto">
            <table class="w-full border-collapse text-sm">
                <thead class="bg-gray-200 dark:bg-gray-700 font-medium">
                    <tr>
                        <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'name','displayName' => 'Build ID','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','displayName' => 'Build ID','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'module_name','displayName' => 'Module','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'module_name','displayName' => 'Module','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'module_description','displayName' => 'Description','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'module_description','displayName' => 'Description','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'created_at','displayName' => 'Created Date','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'created_at','displayName' => 'Created Date','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        <th class="px-4 py-3 font-medium">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr wire:key='<?php echo e($module->id); ?>' class="hover:bg-gray-100 dark:hover:bg-gray-800">
                            <td class="px-4 py-3" title="<?php echo e($module->build->name ?? ''); ?>"><?php echo e($module->build->name ?? ''); ?></td>
                            <td class="px-4 py-3" title="<?php echo e($module->module_name); ?>"><?php echo e($module->module_name); ?></td>
                            <td class="px-4 py-3" title="<?php echo e($module->module_description); ?>">
                                <?php echo e(Str::limit($module->module_description, 30, '...')); ?>

                            </td>
                            <td class="px-4 py-3"><?php echo e($module->created_at->format('d-M-Y')); ?></td>
                            <td class="text-center px-4 py-3">
                                <div class="flex items-center justify-center gap-2">
                                        <button wire:click="edit(<?php echo e($module->id); ?>)" title="Edit"
                                            class="px-2 py-1 hover:text-blue-500 cursor-pointer">
                                            <i class="fa-solid fa-edit"></i>
                                        </button>
                                        <button @click="confirmationModel = true; moduleid = <?php echo e($module->id); ?>" title="Delete"
                                            class="px-2 py-1 text-red-500 cursor-pointer">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="w-full p-4 text-center" colspan="5">No Records found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div><?php echo e($modules->links()); ?></div>
    </div>

    
    <div>
        <div x-show="confirmationModel"
            class="fixed inset-0 flex items-center justify-center z-50 bg-gray-900/50 dark:bg-gray-100/50">
            <div class="bg-white rounded-lg dark:bg-gray-800 shadow-lg p-8">
                <p>Are you sure you want to delete? This action cannot be undone.</p>
                <div class="flex gap-4 items-center justify-center mt-4">
                    <button @click="$wire.delete(moduleid); confirmationModel = false; moduleid = null"
                        class="px-4 py-2 bg-red-500 text-gray-100 rounded-md cursor-pointer">Delete</button>
                    <button @click="confirmationModel = false; moduleid = null"
                        class="px-4 py-2 bg-gray-200 dark:bg-gray-700 dark:text-gray-100 rounded-md cursor-pointer">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    
    <div x-show="$wire.createModule || $wire.editModule"
        class="absolute top-0 left-0 w-full h-full bg-gray-900/50 dark:bg-gray-100/50" id="form">
        <div class="absolute w-full h-full sm:w-auto sm:w-[640px] md:w-[720px] top-0 right-0 bg-white dark:bg-gray-900 overflow-auto">
            <div class="px-8 py-4 flex justify-between items-center border-b border-gray-200 dark:border-gray-700">
                <h3 class="text-lg" x-text="$wire.createModule ? 'Create New Module' : 'Edit Module'"></h3>
                <button wire:click='resetForm' class="text-xl cursor-pointer"><i
                        class="fa-solid fa-xmark"></i></button>
            </div>
            <div class="flex flex-col p-8">
                <form wire:submit.prevent='save'>
                    <div class="grid sm:grid-cols-2 gap-4">
                        
                        <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Build ID','model' => 'build_id'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                            <option value="">Select Build</option>
                                <?php $__empty_1 = true; $__currentLoopData = $builds ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $build): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($build->id); ?>"><?php echo e($build->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option value="">No records found</option>
                                <?php endif; ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                        
                        <?php if (isset($component)) { $__componentOriginal767b2fe2f313e877004be11b5e91bb94 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal767b2fe2f313e877004be11b5e91bb94 = $attributes; } ?>
<?php $component = App\View\Components\InputField::resolve(['label' => 'Module Name','model' => 'module_name','type' => 'text','required' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\InputField::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['autocomplete' => 'module-name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal767b2fe2f313e877004be11b5e91bb94)): ?>
<?php $attributes = $__attributesOriginal767b2fe2f313e877004be11b5e91bb94; ?>
<?php unset($__attributesOriginal767b2fe2f313e877004be11b5e91bb94); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal767b2fe2f313e877004be11b5e91bb94)): ?>
<?php $component = $__componentOriginal767b2fe2f313e877004be11b5e91bb94; ?>
<?php unset($__componentOriginal767b2fe2f313e877004be11b5e91bb94); ?>
<?php endif; ?>

                        
                        <?php if (isset($component)) { $__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb = $attributes; } ?>
<?php $component = App\View\Components\Textarea::resolve(['model' => 'module_description','label' => 'Description','class' => 'col-span-2','rows' => '5','required' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Textarea::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb)): ?>
<?php $attributes = $__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb; ?>
<?php unset($__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb)): ?>
<?php $component = $__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb; ?>
<?php unset($__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb); ?>
<?php endif; ?>
                    </div>

                    <div class="flex items-center justify-center gap-4 mt-4">
                        <button type="submit"
                            class="px-4 py-2 rounded-md bg-blue-500 hover:bg-blue-600 text-white dark:bg-blue-600 dark:hover:bg-blue-500 dark:text-gray-300 cursor-pointer">Save
                            <i wire:loading wire:target='save' class="fa-solid fa-spinner fa-spin"></i></button>
                        <button wire:click='resetForm' type="button" id="cancelButton"
                            class="px-4 py-2 rounded-md bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 cursor-pointer">Cancel
                            <i wire:loading wire:target='resetForm' class="fa-solid fa-spinner fa-spin"></i></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views\livewire\module\modules.blade.php ENDPATH**/ ?>