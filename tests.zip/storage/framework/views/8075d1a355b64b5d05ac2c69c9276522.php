<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'class' => '',
    'label' => 'Select Option',
    'required' => false,
    'options' => [],
    'selectedOption' => null,
    'model' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'class' => '',
    'label' => 'Select Option',
    'required' => false,
    'options' => [],
    'selectedOption' => null,
    'model' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="flex flex-col gap-2 w-full <?php echo e($class); ?>">
    <label>
        <?php echo e($label); ?>

        <?php if($required): ?>
            <span class="text-red-500">*</span>
        <?php endif; ?>
    </label>

    <div x-data="{ open: false }" @click.outside="open = false" class="relative">
        <!-- Content Box -->
        <div @click="open = !open"
            class="flex items-center px-4 py-2 rounded-md border border-gray-200 dark:border-gray-700 cursor-pointer">
            <span class="w-full"><?php echo e($selectedOption ?? 'Select an option'); ?></span>
            <button x-show="<?php echo e($selectedOption ? 'true' : 'false'); ?>" @click="$wire.set('selectedOption', null); open = false;" type="button">
                <i class="fa-solid fa-xmark"></i>
            </button>
            <i :class="{ 'fa-angle-down': !open, 'fa-angle-up': open }" class="fa-solid ml-2 text-gray-500"></i>
        </div>

        <!-- Dropdown -->
        <div x-show="open" x-transition class="absolute z-10 mt-2 w-full rounded-md shadow-lg bg-gray-100 dark:bg-gray-800 max-h-72 overflow-auto">
            <div class="border-b dark:border-gray-700">
                <input wire:model.debounce.300ms="search" type="text"
                    class="w-full px-4 py-3 text-sm dark:bg-gray-800 outline-none" placeholder="Type to search">
            </div>
            <div>
                <?php $__empty_1 = true; $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <button wire:click="selectOption('<?php echo e($option['id']); ?>')" type="button"
                        class="py-3 px-4 bg-white dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-left w-full">
                        <?php echo e($option['name']); ?>

                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="py-3 px-4 bg-white dark:bg-gray-800 text-left w-full">
                        No records found
                    </p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Error -->
        <?php $__errorArgs = [$model];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-red-500"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div><?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views\livewire\components\searchable-select.blade.php ENDPATH**/ ?>