<button type="<?php echo e($type); ?>" id="<?php echo e($model); ?>"
    <?php if(strlen($model) > 0 && $type != 'submit'): ?>
    wire:click="<?php echo e($model); ?>"

    <?php endif; ?>
    class="px-4 py-2 rounded-md bg-blue-500 hover:bg-blue-600 text-gray-100 dark:bg-blue-600 dark:hover:bg-blue-500 cursor-pointer <?php echo e($class); ?>"
    >
    <?php echo e($slot); ?>

    <i wire:loading wire:target="<?php echo e($model); ?>" class="fa-solid fa-spinner fa-spin"></i>
</button>
<?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views/components/primary-button.blade.php ENDPATH**/ ?>