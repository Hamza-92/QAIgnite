<div>
    <div class="px-8 pt-2 w-full flex items-end gap-1 border-b dark:border-gray-700 transition-colors duration-200">
        <a href="<?php echo e(route('reports.defect-report')); ?>" wire:navigate class="p-2 border-b-2 border-blue-500">Defect Report</a>
        <a href="<?php echo e(route('reports.test-case-report')); ?>" wire:navigate class="p-2 hover:border-b-2 border-blue-500">Test Case Report</a>
    </div>
    <div
        class="px-8 py-4 flex items-center flex-wrap gap-4 justify-between border-b border-gray-200 dark:border-gray-700">
        <h2 class="text-lg">Defect Report</h2>
    </div>

    
    <div class="px-8 py-4">
        <div x-data="{ open_model: true }" class="w-full">
            <div @click="open_model = !open_model"
                class="w-full flex items-center justify-between px-4 py-2 cursor-pointer text-white bg-blue-500 hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-500 transition-colors duration-300 rounded-t-md"
                :class="{ 'rounded-md': !open_model }">
                <h3 class="text-lg font-medium">Defect Report Filter</h3>
                <span class="px-2 py-1 bg-white text-gray-900 font-bold rounded transition-transform duration-300"
                    :class="{ 'rotate-180': open_model }" x-text="open_model ? '−' : '+'"></span>
            </div>

            <div x-show="open_model" x-collapse.duration.300ms
                class="p-6 grid md:grid-cols-2 gap-6 overflow-hidden border dark:border-gray-700">
                <div class="grid sm:grid-cols-2 gap-2">
                    
                    <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Build','model' => 'build_id','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="all">All</option>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $builds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $build): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option class="overflow-ellipsis" wire:key='<?php echo e($build->id); ?>'
                                value="<?php echo e($build->id); ?>"><?php echo e($build->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                    
                    <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Module','model' => 'module_id','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="all">All</option>
                        <!--[if BLOCK]><![endif]--><?php if(isset($modules)): ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="overflow-ellipsis" wire:key='<?php echo e($module->id); ?>'
                                    value="<?php echo e($module->id); ?>"><?php echo e($module->module_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                    
                    <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Requirement','model' => 'requirement_id','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="all">All</option>
                        <!--[if BLOCK]><![endif]--><?php if(isset($requirements)): ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="overflow-ellipsis" wire:key='<?php echo e($requirement->id); ?>'
                                    value="<?php echo e($requirement->id); ?>"><?php echo e($requirement->requirement_title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                    
                    <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Test Scenario','model' => 'test_scenario_id','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="all">All</option>
                        <!--[if BLOCK]><![endif]--><?php if(isset($test_scenarios)): ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $test_scenarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test_scenario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="overflow-ellipsis" wire:key='<?php echo e($test_scenario->id); ?>'
                                    value="<?php echo e($test_scenario->id); ?>"><?php echo e($test_scenario->ts_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                    
                    <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Test Case','model' => 'test_case_id','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="all">All</option>
                        <!--[if BLOCK]><![endif]--><?php if(isset($test_cases)): ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $test_cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test_case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="overflow-ellipsis" wire:key='<?php echo e($test_case->id); ?>'
                                    value="<?php echo e($test_case->id); ?>"><?php echo e($test_case->tc_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                    
                    <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Defect Type','model' => 'defect_type','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="all">All</option>
                        <option value="functional">Functional</option>
                        <option value="ui/ux">UI/UX</option>
                        <option value="cross-browser">Cross-Browser</option>
                        <option value="cross-platform">Cross-Platform</option>
                        <option value="field-validation">Field Validation</option>
                        <option value="performance">Performance</option>
                        <option value="security">Security</option>
                        <option value="usability">Usability</option>
                        <option value="compatibility">Compatibility</option>
                        <option value="integration">Integration</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                    
                    <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Defect Status','model' => 'defect_status','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="all">All</option>
                        <option value="open">Open</option>
                        <option value="closed">Closed</option>
                        <option value="fixed">Fixed</option>
                        <option value="re-open">Re-Open</option>
                        <option value="not-a-bug">Not a Bug</option>
                        <option value="resolved">Resolved</option>
                        <option value="deffer">Deffer</option>
                        <option value="too-limitations">Too Limitations</option>
                        <option value="not-reproducible">Not Reproducible</option>
                        <option value="user-interface">User Interface</option>
                        <option value="beta">Beta</option>
                        <option value="in-progress">In Progress</option>
                        <option value="to-do">To Do</option>
                        <option value="in-review">In Review</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                    
                    <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Defect Priority','model' => 'defect_priority','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="all">All</option>
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                    
                    <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Defect Severity','model' => 'defect_severity','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="all">All</option>
                        <option value="blocker">Blocker</option>
                        <option value="major">Major</option>
                        <option value="minor">Minor</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                    
                    <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Defect Environment','model' => 'defect_environment','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="all">All</option>
                        <option value="production">Production</option>
                        <option value="staging">Staging</option>
                        <option value="development">Development</option>
                        <option value="testing">Testing</option>
                        <option value="qa">QA</option>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                    
                    <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Created By','model' => 'created_by','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="all">All</option>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $created_by_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option wire:key='<?php echo e($user->id); ?>' value="<?php echo e($user->id); ?>">
                                <?php echo e($user->username); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                    
                    <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Assigned To','model' => 'assigned_to','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <option value="all">All</option>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $assigned_to_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option wire:key='<?php echo e($user->id); ?>' value="<?php echo e($user->id); ?>">
                                <?php echo e($user->username); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
                </div>

                
                <div class="space-y-4">
                    <h3 class="text-lg text-blue-500 mb-2">Extended Search</h3>
                    <div class="grid grid-cols-2 sm:grid-cols-3 gap-4 items-start">
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="def_name" value="def_name" disabled
                                wire:model='reportColumns'>
                            <label for="def_name">Defect ID</label>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="def_description" value="def_description"
                                wire:model='reportColumns'>
                            <label for="def_description">Description</label>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="def_status" value="def_status" wire:model='reportColumns'>
                            <label for="def_status">Status</label>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="def_type" value="def_type" wire:model='reportColumns'>
                            <label for="def_type">Type</label>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="def_priority" value="def_priority"
                                wire:model='reportColumns'>
                            <label for="def_priority">Priority</label>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="def_severity" value="def_severity"
                                wire:model='reportColumns'>
                            <label for="def_severity">Severity</label>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="def_environment" value="def_environment"
                                wire:model='reportColumns'>
                            <label for="def_environment">Environment</label>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="def_steps_to_reproduce" value="def_steps_to_reproduce"
                                wire:model='reportColumns'>
                            <label for="def_steps_to_reproduce">Steps to Reproduce</label>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="def_expected_result" value="def_expected_result"
                                wire:model='reportColumns'>
                            <label for="def_expected_result">Expected Result</label>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="def_actual_result" value="def_actual_result"
                                wire:model='reportColumns'>
                            <label for="def_actual_result">Actual Result</label>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="def_requirement_id" value="def_requirement_id"
                                wire:model='reportColumns'>
                            <label for="def_requirement_id">Requirement</label>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="def_assigned_to" value="def_assigned_to"
                                wire:model='reportColumns'>
                            <label for="def_assigned_to">Assigned To</label>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="created_at" value="created_at" wire:model='reportColumns'>
                            <label for="created_at">Created Date</label>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="checkbox" id="updated_at" value="updated_at" wire:model='reportColumns'>
                            <label for="updated_at">Closure Date</label>
                        </div>
                    </div>
                    <button wire:click='generateReport' @click='open_model = false' class="px-4 py-2 bg-blue-500 text-white rounded-md">Generate
                        Report</button>
                </div>
            </div>
        </div>
    </div>

    <!--[if BLOCK]><![endif]--><?php if(isset($defects)): ?>
        <div class="px-8 py-6 mt-8">
            <div class="w-full flex items-end justify-between gap-4 flex-wrap">
                <?php if (isset($component)) { $__componentOriginal52aeb1f981ab196666a9afcb1710a1a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1 = $attributes; } ?>
<?php $component = App\View\Components\TableEntries::resolve(['entries' => 'perPage'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table-entries'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\TableEntries::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1)): ?>
<?php $attributes = $__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1; ?>
<?php unset($__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52aeb1f981ab196666a9afcb1710a1a1)): ?>
<?php $component = $__componentOriginal52aeb1f981ab196666a9afcb1710a1a1; ?>
<?php unset($__componentOriginal52aeb1f981ab196666a9afcb1710a1a1); ?>
<?php endif; ?>
                <div class="px-4 py-2 flex flex-col gap-2 justify-start bg-gray-100 dark:bg-gray-800 rounded-md">
                    <p class="text-blue-500 dark:text-blue-400">Export As</p>
                    <div class="flex gap-4 flex-wrap">
                        <button wire:click='downloadDocReport' class="text-blue-500 text-5xl cursor-pointer" title="Export as DOC">
                            <i class="fas fa-file-word"></i>
                        </button>
                        <button wire:click='downloadExcelReport' class="text-green-500 text-5xl cursor-pointer" title="Export as Excel">
                            <i class="fas fa-file-excel"></i>
                        </button>
                        <button wire:click='downloadCsvReport' class="text-orange-500 text-5xl cursor-pointer" title="Export as CSV">
                            <i class="fas fa-file-csv"></i>
                        </button>
                        <button wire:click='downloadPdfReport' class="text-red-500 text-5xl cursor-pointer" title="Export as PDF">
                            <i class="fas fa-file-pdf"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="mt-4 border border-gray-200 dark:border-gray-700 overflow-auto">
                <table class="w-full border-collapse text-sm">
                    <thead class="bg-gray-200 dark:bg-gray-700 font-medium">
                        <tr>
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_name', $reportColumns)): ?>
                                <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'def_name','displayName' => 'Defect','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'def_name','displayName' => 'Defect','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_severity', $reportColumns)): ?>
                                <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'def_severity','displayName' => 'Severity','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'def_severity','displayName' => 'Severity','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_description', $reportColumns)): ?>
                                <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'def_description','displayName' => 'Description','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'def_description','displayName' => 'Description','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_status', $reportColumns)): ?>
                                <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'def_status','displayName' => 'Status','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'def_status','displayName' => 'Status','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_type', $reportColumns)): ?>
                                <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'def_type','displayName' => 'Type','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'def_type','displayName' => 'Type','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_priority', $reportColumns)): ?>
                                <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'def_priority','displayName' => 'Priority','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'def_priority','displayName' => 'Priority','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_environment', $reportColumns)): ?>
                                <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'def_environment','displayName' => 'Environment','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'def_environment','displayName' => 'Environment','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_steps_to_reproduce', $reportColumns)): ?>
                                <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'def_steps_to_reproduce','displayName' => 'Steps to Reproduce','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'def_steps_to_reproduce','displayName' => 'Steps to Reproduce','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_expected_result', $reportColumns)): ?>
                                <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'def_expected_result','displayName' => 'Expected Results','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'def_expected_result','displayName' => 'Expected Results','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_actual_result', $reportColumns)): ?>
                                <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'def_actual_result','displayName' => 'Actual Results','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'def_actual_result','displayName' => 'Actual Results','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_requirement_id', $reportColumns)): ?>
                                <th class="px-4 py-3 font-medium text-left">Requirement</th>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_assigned_to', $reportColumns)): ?>
                                <th class="px-4 py-3 font-medium text-left">Assigned To</th>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_created_by', $reportColumns)): ?>
                                <th class="px-4 py-3 font-medium text-left">Created By</th>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('created_at', $reportColumns)): ?>
                                <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'created_at','displayName' => 'Created At','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'created_at','displayName' => 'Created At','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('updated_at', $reportColumns)): ?>
                                <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'updated_at','displayName' => 'Closure Date','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'updated_at','displayName' => 'Closure Date','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $defects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $defect): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr wire:key='<?php echo e($defect->id); ?>' class="hover:bg-gray-100 dark:hover:bg-gray-800">
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_name', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <?php echo e($defect->def_name); ?>

                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_severity', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <?php echo e($defect->def_severity); ?>

                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_description', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <?php echo e($defect->def_description); ?>

                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_status', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <?php echo e($defect->def_status); ?>

                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_type', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <?php echo e($defect->def_type); ?>

                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_priority', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <?php echo e($defect->def_priority); ?>

                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_environment', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <?php echo e($defect->def_environment); ?>

                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_steps_to_reproduce', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <?php echo e($defect->def_steps_to_reproduce); ?>

                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_expected_result', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <?php echo e($defect->def_expected_result); ?>

                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_actual_result', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <?php echo e($defect->def_actual_result); ?>

                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_requirement_id', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <?php echo e($defect->requirement_title ?? ''); ?>

                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('def_assigned_to', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <?php echo e($defect->assigned_user ?? ''); ?>

                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('created_user', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <?php echo e($defect->created_user ?? 'System'); ?>

                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('created_at', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <?php echo e($defect->created_at->format('Y-m-d H:i')); ?>

                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <!--[if BLOCK]><![endif]--><?php if($reportColumns && in_array('updated_at', $reportColumns)): ?>
                                    <td class="px-4 py-3">
                                        <!--[if BLOCK]><![endif]--><?php if($defect->def_status === 'closed'): ?>
                                            <?php echo e($defect->updated_at->format('Y-m-d H:i')); ?>

                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="100%"
                                    class="px-4 py-3 text-center border border-gray-200 dark:border-gray-700">
                                    No defects found matching your criteria.
                                </td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views/livewire/reports/defect-report.blade.php ENDPATH**/ ?>