<div x-data="{ showModel: false, showDetailsModel: false, project_id: null }">

    <!--[if BLOCK]><![endif]--><?php if(session('error')): ?>
        <div class="px-8 py-2">
            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['type' => 'error','message' => session('error')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'error','message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('error'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


    <div
        class="px-8 py-4 flex-wrap gap-2 flex items-center justify-between border-b border-gray-200 dark:border-gray-700">
        <button x-on:click="$wire.createProject = true"
            class="px-4 py-2 bg-blue-500 hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-500 text-white rounded-md cursor-pointer"
            type="button">Create Project</button>
        <a href="<?php echo e(route('projects.archive')); ?>"
            class="px-4 py-2 bg-indigo-500 hover:bg-indigo-600 dark:bg-indigo-600 dark:hover:bg-indigo-500 text-white rounded-md cursor-pointer"
            wire:navigate>Archived Projects</a>
    </div>

    
    <div class="px-8 py-4">
        <div class="flex flex-wrap gap-2 items-center justify-between">
            <?php if (isset($component)) { $__componentOriginal52aeb1f981ab196666a9afcb1710a1a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1 = $attributes; } ?>
<?php $component = App\View\Components\TableEntries::resolve(['entries' => 'perPage'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table-entries'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\TableEntries::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1)): ?>
<?php $attributes = $__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1; ?>
<?php unset($__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52aeb1f981ab196666a9afcb1710a1a1)): ?>
<?php $component = $__componentOriginal52aeb1f981ab196666a9afcb1710a1a1; ?>
<?php unset($__componentOriginal52aeb1f981ab196666a9afcb1710a1a1); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d = $attributes; } ?>
<?php $component = App\View\Components\SearchField::resolve(['search' => 'search','resetMethod' => 'resetSearch'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('search-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SearchField::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d)): ?>
<?php $attributes = $__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d; ?>
<?php unset($__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d)): ?>
<?php $component = $__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d; ?>
<?php unset($__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d); ?>
<?php endif; ?>
        </div>
        <div class="mt-4 border border-gray-200 dark:border-gray-700 overflow-x-auto">
            <table class="w-full border-collapse text-sm">
                <thead class="bg-gray-200 dark:bg-gray-700 font-medium">
                    <tr>
                        <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'name','displayName' => 'Name','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','displayName' => 'Name','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'user_name','displayName' => 'Created By','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'user_name','displayName' => 'Created By','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'status','displayName' => 'Status','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'status','displayName' => 'Status','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'created_at','displayName' => 'Created Date','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'created_at','displayName' => 'Created Date','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        <th class="px-4 py-3 font-medium">Actions</th>
                    </tr>
                </thead>
                <tbody class="text-sm ">
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr wire:key='<?php echo e($project->id); ?>' class="hover:bg-gray-100 dark:hover:bg-gray-800">
                            <td class="px-4 py-3"><?php echo e($project->name); ?></td>
                            <td class="px-4 py-3"><?php echo e($project->user->name); ?></td>
                            <td class="px-4 py-3"><?php echo e($project->status); ?></td>
                            <td class="px-4 py-3"><?php echo e($project->created_at->format('M j, Y g:i A')); ?></td>
                            <td class="px-4 py-3 flex justify-center whitespace-nowrap">
                                <div class="relative" x-data="{ open: false }">
                                    <button type="button" @click="open = !open"
                                        class="px-4 py-1 rounded-md bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-gray-100 cursor-pointer">
                                        <i class="fa-solid fa-ellipsis-vertical"></i>
                                    </button>
                                    <div x-show="open" @click.outside="open = false" x-transition
                                        class="absolute top-1/2 right-full mr-3 transform -translate-y-1/2 p-1 text-md bg-white dark:bg-gray-800 rounded-md border dark:border-gray-700 shadow-lg z-10 flex items-center justify-center gap-2 before:absolute before:top-1/2 before:left-full before:-translate-y-1/2 before:w-0 before:h-0 before:border-[6px] before:border-t-transparent before:border-b-transparent before:border-l-white dark:before:border-l-gray-800 before:border-r-transparent">
                                        <!-- View Button -->
                                        <button type="button" @click='showDetailsModel = true'
                                            wire:click='loadProject(<?php echo e($project->id); ?>)' wire:loading.attr="disabled"
                                            class="px-2 py-1 text-green-600 hover:text-blue-800 dark:text-green-400 dark:hover:text-green-300 transition-colors border-r dark:border-gray-700 cursor-pointer"
                                            title="View Project">
                                            <i class="fa-solid fa-eye"></i>
                                        </button>

                                        <!-- Edit Button -->
                                        <button type="button" wire:click="edit(<?php echo e($project->id); ?>)"
                                            
                                            class="px-2 py-1 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 transition-colors border-r dark:border-gray-700 cursor-pointer"
                                            title="Edit Project">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </button>

                                        
                                        <button @click='showModel = true; project_id = <?php echo e($project->id); ?>'
                                            class="px-2 py-1 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 transition-colors"
                                            type="button" title="Archive Project">
                                            <i class="fa-solid fa-box-archive"></i>
                                        </button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="w-full p-4 text-center" colspan="5">No Records found</td>
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
        <div class="mt-4"><?php echo e($projects->links()); ?></div>
    </div>

    
    <div x-show="showModel" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in duration-200"
        x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0"
        @keydown.escape.window="showModel = false; project_id = null"
        class="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/50 dark:bg-gray-100/50"
        style="display: none;">
        <div
            class="flex flex-col items-center bg-white dark:bg-gray-900 rounded-lg p-6 w-full max-w-md mx-auto shadow-lg">
            <div class="text-yellow-600 dark:text-yellow-400 mb-2 text-3xl">
                <i class="fa-solid fa-triangle-exclamation"></i>
            </div>
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-2">Archive Project</h3>
            <p class="text-sm text-gray-700 dark:text-gray-300">Are you sure you want to archive this project?</p>

            <div class="mt-6 space-x-3">
                <button type="button" @click="$wire.archiveProject(project_id); showModel = false; project_id = null"
                    class="px-5 py-2 rounded-md text-white bg-yellow-600 hover:bg-yellow-700 focus:ring-2 focus:ring-yellow-400">
                    Archive
                </button>
                <button type="button" @click="showModel = false; project_id = null"
                    class="px-5 py-2 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 focus:ring-2 focus:ring-gray-400">
                    Cancel
                </button>
            </div>
        </div>
    </div>

    
    <div x-show="showDetailsModel" x-transition:enter="transition ease-out duration-300"
        x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
        x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
        class="fixed inset-0 flex items-center justify-center bg-gray-500/50 backdrop-blur-sm z-50" x-cloak>
        
        <div class="w-full mx-4 md:w-[700px] lg:w-[800px] max-h-[90vh] bg-white dark:bg-gray-800 rounded-lg shadow-xl overflow-hidden flex flex-col"
            x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 scale-95"
            x-transition:enter-end="opacity-100 scale-100" x-transition:leave="transition ease-in duration-200"
            x-transition:leave-start="opacity-100 scale-100" x-transition:leave-end="opacity-0 scale-95"
            @keydown.escape.window="showDetailsModel=false; $wire.project=null">
            
            <div
                class="p-5 flex justify-between items-center border-b dark:border-gray-700 bg-gray-50 dark:bg-gray-900 sticky top-0 z-10">
                <h2 class="text-xl font-semibold text-gray-800 dark:text-gray-200 truncate max-w-[80%]">
                    Project Details: <span
                        class="text-blue-600 dark:text-blue-400"><?php echo e($project_detail->name ?? 'N/A'); ?></span>
                </h2>
                <button @click='showDetailsModel=false; $wire.project_detail=null' type="button"
                    class="px-2 py-1  text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 text-xl transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500"
                    aria-label="Close modal">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            
            <div class="flex-1 overflow-y-auto p-5 md:p-6">
                <div class="space-y-6">
                    <!--[if BLOCK]><![endif]--><?php if($project_detail): ?>
                        
                        <div>
                            <h3 class="font-medium text-gray-700 dark:text-gray-300 mb-2">Project Status</h3>
                            <div class="text-gray-600 dark:text-gray-400">
                                <?php echo e($project_detail->status ?? ''); ?>

                            </div>
                        </div>
                        
                        <div>
                            <h3 class="font-medium text-gray-700 dark:text-gray-300 mb-2">Project Type</h3>
                            <div class="text-gray-600 dark:text-gray-400">
                                <!--[if BLOCK]><![endif]--><?php if(is_array($project_detail->type)): ?>
                                    <!--[if BLOCK]><![endif]--><?php if(count($project_detail->type)): ?>
                                        <?php echo e(implode(', ', $project_detail->type)); ?>

                                    <?php else: ?>
                                        Not Set
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <?php elseif(!empty($project_detail->type)): ?>
                                    <?php echo e($project_detail->type); ?>

                                <?php else: ?>
                                    Not Set
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                        
                        <div>
                            <h3 class="font-medium text-gray-700 dark:text-gray-300 mb-2">Project Descripion</h3>
                            <div class="text-gray-600 dark:text-gray-400">
                                <?php echo e($project_detail->description ?? 'N/A'); ?>

                            </div>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
            
            <div
                class="p-4 border-t dark:border-gray-700 bg-gray-50 dark:bg-gray-900 flex justify-end items-center gap-3 sticky bottom-0">
                <button @click='showDetailsModel = false; $wire.project_detail = null' type="button"
                    class="px-4 py-2 text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-gray-100 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 rounded-md transition-colors w-full sm:w-auto order-2 sm:order-1">
                    Close
                </button>
            </div>
        </div>
    </div>

    
    <div x-show="$wire.createProject || $wire.editProject" x-transition:enter="transition ease-out duration-200"
    x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
    x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100"
    x-transition:leave-end="opacity-0"
    class="fixed inset-0 z-50 overflow-y-auto" x-cloak>

        <!-- Background overlay -->
        <div class="fixed inset-0 bg-gray-900/50 dark:bg-gray-100/50" x-transition.opacity></div>

        <div class="absolute w-full h-full max-w-3xl top-0 right-0 bg-white dark:bg-gray-900 overflow-auto">
            <div
                class="sticky top-0 z-10 px-8 py-4 flex justify-between items-center border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900">
                <h3 class="text-lg" x-text="$wire.createProject ? 'Create new Project' : 'Edit Project'"></h3>
                <button wire:click='resetForm' type="button"
                    class="p-2 -mr-2 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors cursor-pointer"
                    aria-label="Close">
                    <i class="fa-solid fa-xmark text-xl"></i>
                </button>
            </div>
            <div class="p-8">
                <form wire:submit.prevent='save'>
                    <div class="grid sm:grid-cols-2 gap-4">
                        
                        <?php if (isset($component)) { $__componentOriginal767b2fe2f313e877004be11b5e91bb94 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal767b2fe2f313e877004be11b5e91bb94 = $attributes; } ?>
<?php $component = App\View\Components\InputField::resolve(['label' => 'Name','model' => 'name','type' => 'text','required' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\InputField::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['autocomplete' => 'project-name']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal767b2fe2f313e877004be11b5e91bb94)): ?>
<?php $attributes = $__attributesOriginal767b2fe2f313e877004be11b5e91bb94; ?>
<?php unset($__attributesOriginal767b2fe2f313e877004be11b5e91bb94); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal767b2fe2f313e877004be11b5e91bb94)): ?>
<?php $component = $__componentOriginal767b2fe2f313e877004be11b5e91bb94; ?>
<?php unset($__componentOriginal767b2fe2f313e877004be11b5e91bb94); ?>
<?php endif; ?>

                        
                        <div class="flex flex-col gap-1">
                            <label>Type</label>
                            <div x-data='{open_model : false}' class="relative w-full"
                                @click.outside="open_model = false" @close.stop="open_model = false">
                                <div @click.stop="open_model = !open_model"
                                    class="w-full flex items-center rounded-md border border-gray-200 dark:border-gray-700 px-4 py-1">
                                    <div class="w-full flex items-center justify-start gap-2 flex-wrap">
                                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="bg-gray-200 dark:bg-gray-800 rounded-sm py-1 ">
                                                <span
                                                    class="pr-1 border-r dark:border-gray-700 px-2"><?php echo e($type); ?></span>
                                                <button wire:click='removeType(<?php echo e($index); ?>)'
                                                    class="px-1 pr-2" type="button">
                                                    <i wire:loading.remove
                                                        wire:target='removeType(<?php echo e($index); ?>)'
                                                        class="fa-solid fa-xmark cursor-pointer"></i>
                                                    <i wire:loading wire:target='removeType(<?php echo e($index); ?>)'
                                                        class="fa-solid fa-spinner fa-spin"></i>
                                                </button>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <span class="text-gray-700 dark:text-gray-300 py-1">Select project
                                                type</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <i wire:loading.remove wire:target='addType'
                                        class="fa-solid fa-angle-down ml-2 text-gray-500"></i>
                                    <i wire:loading wire:target='addType'
                                        class="fa-solid fa-spinner fa-spin ml-2 text-gray-500"></i>
                                </div>
                                <div x-show='open_model'
                                    class="absolute z-10 mt-2 w-full shadow-lg bg-gray-100 max-h-72 overflow-auto">

                                    <div>
                                        <button id="" type="button" wire:click = 'addType("Web")'
                                            @click = 'open_model = false'
                                            class="flex items-center justify-between py-3 px-4 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-left w-full">
                                            Web
                                        </button>
                                        <button id="" type="button"
                                            wire:click = 'addType("Responsive Web")' @click = 'open_model = false'
                                            class="flex items-center justify-between py-3 px-4 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-left w-full">
                                            Responsive Web
                                        </button>
                                        <button id="" type="button"
                                            wire:click = 'addType("Native Mobile App")' @click = 'open_model = false'
                                            class="flex items-center justify-between py-3 px-4 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-left w-full">
                                            Native Mobile App
                                        </button>
                                        <button id="" type="button" wire:click = 'addType("Desktop")'
                                            @click = 'open_model = false'
                                            class="flex items-center justify-between py-3 px-4 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-left w-full">
                                            Desktop
                                        </button>

                                    </div>
                                </div>
                            </div>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        
                        <!--[if BLOCK]><![endif]--><?php if($editProject): ?>
                        <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Status','model' => 'status','required' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                            <option value="In Progress">In Progress</option>
                            <option value="On Hold">On Hold</option>
                            <option value="Completed">Completed</option>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        
                        <?php if (isset($component)) { $__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb = $attributes; } ?>
<?php $component = App\View\Components\Textarea::resolve(['model' => 'description','label' => 'Description','rows' => '5','class' => 'col-span-full'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Textarea::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb)): ?>
<?php $attributes = $__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb; ?>
<?php unset($__attributesOriginal0eb289d06f2ec5a97cf23eec2de5caeb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb)): ?>
<?php $component = $__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb; ?>
<?php unset($__componentOriginal0eb289d06f2ec5a97cf23eec2de5caeb); ?>
<?php endif; ?>
                    </div>
                    <div class="flex items-center justify-center gap-4 mt-8">
                        <button type="submit" wire:loading.attr='disabled'
                            class="px-8 py-3 w-42 transition duration-200 rounded-md bg-blue-500 hover:bg-blue-600 text-xl text-white dark:bg-blue-600 dark:hover:bg-blue-500 cursor-pointer">Save
                            <i wire:loading wire:target='save' class="fa-solid fa-spinner fa-spin"></i></button>
                        <button wire:click='resetForm' type="button" id="cancelButton"
                            class="px-8 py-3 text-xl w-42 transition duration-200 rounded-md bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 cursor-pointer">
                            <span>Cancel</span>
                            <i wire:loading wire:target='resetForm' class="fa-solid fa-spinner fa-spin"></i></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views/livewire/project/projects.blade.php ENDPATH**/ ?>