<div
    x-data='{filter_box : false, build_col:false, module_col:false, requirement_title_col:true, requirement_summary_col:true, status_col:true, created_date_col:true }'>

    <div class="px-8 py-4">
        <div class="flex items-center justify-between flex-wrap gap-4">
            
            <?php if (isset($component)) { $__componentOriginal52aeb1f981ab196666a9afcb1710a1a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1 = $attributes; } ?>
<?php $component = App\View\Components\TableEntries::resolve(['entries' => 'perPage'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table-entries'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\TableEntries::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1)): ?>
<?php $attributes = $__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1; ?>
<?php unset($__attributesOriginal52aeb1f981ab196666a9afcb1710a1a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52aeb1f981ab196666a9afcb1710a1a1)): ?>
<?php $component = $__componentOriginal52aeb1f981ab196666a9afcb1710a1a1; ?>
<?php unset($__componentOriginal52aeb1f981ab196666a9afcb1710a1a1); ?>
<?php endif; ?>

            <div class="flex items-center gap-4">
                
                <?php if (isset($component)) { $__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d = $attributes; } ?>
<?php $component = App\View\Components\SearchField::resolve(['search' => 'search','placeholder' => 'Search...','resetMethod' => 'resetSearch'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('search-field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SearchField::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d)): ?>
<?php $attributes = $__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d; ?>
<?php unset($__attributesOriginaldd220e76ced280f0b6031f9fad0e6d9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d)): ?>
<?php $component = $__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d; ?>
<?php unset($__componentOriginaldd220e76ced280f0b6031f9fad0e6d9d); ?>
<?php endif; ?>

                <div x-data='{open_model:false}' @click.outside="open_model = false" @close.stop="open_model = false">
                    <button x-on:click='open_model = !open_model' type="button" title="Select Columns"
                        class="text-2xl text-gray-900 dark:text-gray-100 relative">
                        <i class="fa-solid fa-table-columns"></i>
                    </button>
                    <div x-show='open_model' x-transition:enter="transition ease-out duration-200"
                        x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100"
                        x-transition:leave="transition ease-in duration-75"
                        x-transition:leave-start="opacity-100 scale-100" x-transition:leave-end="opacity-0 scale-95"
                        class="absolute right-20 z-10 mt-2 rounded-md shadow-lg bg-gray-100 dark:bg-gray-800 max-h-72 overflow-auto">
                        <div>
                            <div class="flex items-center px-4 py-3 border-b dark:border-gray-700">
                                <input name="build_col" id="build_col" type="checkbox"
                                    class="dark:bg-gray-700" x-model="build_col">
                                <label for="build_col" class="pl-4 w-full">Build</label>
                            </div>
                            <div class="flex items-center px-4 py-3 border-b dark:border-gray-700">
                                <input name="build_col" id="module_col" type="checkbox"
                                    class="dark:bg-gray-700" x-model="module_col">
                                <label for="module_col" class="pl-4 w-full">Module</label>
                            </div>
                            <div class="flex items-center px-4 py-3 border-b dark:border-gray-700">
                                <input name="requirement_title_col" id="requirement_title_col" type="checkbox"
                                    class="dark:bg-gray-700" x-model="requirement_title_col">
                                <label for="requirement_title_col" class="pl-4 w-full">Requirement Title</label>
                            </div>
                            <div class="flex items-center px-4 py-3 border-b dark:border-gray-700">
                                <input name="requirement_summary_col" id="requirement_summary_col" type="checkbox"
                                    class="dark:bg-gray-700" x-model="requirement_summary_col">
                                <label for="requirement_summary_col" class="pl-4 w-full">Requirement Summary</label>
                            </div>
                            <div class="flex items-center px-4 py-3 border-b dark:border-gray-700">
                                <input name="status_col" id="status_col" type="checkbox" class="dark:bg-gray-700"
                                    x-model="status_col">
                                <label for="status_col" class="pl-4 w-full">Status</label>
                            </div>
                            <div class="flex items-center px-4 py-3">
                                <input name="created_date_col" id="created_date_col" type="checkbox"
                                    class="dark:bg-gray-600" x-model="created_date_col">
                                <label for="created_date_col" class="pl-4 w-full">Created Date</label>
                            </div>
                        </div>
                    </div>
                </div>
                <button x-on:click='filter_box = !filter_box' type="button" title="Filter"
                    class="text-2xl text-gray-900 dark:text-gray-100"><i class="fa-solid fa-filter"></i></button>
            </div>
        </div>
        <div class="mt-4 border border-gray-200 dark:border-gray-700 overflow-auto">
            <table class="w-full border-collapse text-sm">
                <thead class="bg-gray-200 dark:bg-gray-700 font-medium">
                    <tr>
                        <template x-if="build_col">
                            <th class="px-4 py-3 text-left font-medium">Build</th>
                        </template>
                        <template x-if="module_col">
                            <th class="px-4 py-3 text-left font-medium">Module</th>
                        </template>
                        <template x-if="requirement_title_col">
                            <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'requirement_title','displayName' => 'Requirement Title','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'requirement_title','displayName' => 'Requirement Title','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        </template>
                        <template x-if="requirement_summary_col">
                            <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'requirement_summary','displayName' => 'Summary','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'requirement_summary','displayName' => 'Summary','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        </template>
                        <template x-if="status_col">
                            <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'status','displayName' => 'Status','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'status','displayName' => 'Status','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        </template>
                        <template x-if="created_date_col">
                            <?php if (isset($component)) { $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sortable-th','data' => ['name' => 'created_at','displayName' => 'Created Date','sortBy' => $sortBy,'sortDir' => $sortDir]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sortable-th'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'created_at','displayName' => 'Created Date','sortBy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortBy),'sortDir' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sortDir)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $attributes = $__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__attributesOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07)): ?>
<?php $component = $__componentOriginal3c1df23c66879bbdd25946c6c08cdc07; ?>
<?php unset($__componentOriginal3c1df23c66879bbdd25946c6c08cdc07); ?>
<?php endif; ?>
                        </template>
                        <th class="px-4 py-3 font-medium">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr wire:key='<?php echo e($requirement->id); ?>' class="hover:bg-gray-100 dark:hover:bg-gray-800">
                            <template x-if="build_col">
                                <td class="px-4 py-3"><?php echo e($requirement->build->name ?? ''); ?></td>
                            </template>
                            <template x-if="module_col">
                                <td class="px-4 py-3"><?php echo e($requirement->module->module_name ?? ''); ?></td>
                            </template>
                            <template x-if="requirement_title_col">
                                <td class="px-4 py-3" title="<?php echo e($requirement->requirement_title); ?>"><?php echo e($requirement->requirement_title); ?></td>
                            </template>
                            <template x-if="requirement_summary_col">
                                <td class="px-4 py-3" title="<?php echo e($requirement->requirement_summary); ?>"><?php echo e(Str::limit($requirement->requirement_summary, 30, '...')); ?></td>
                            </template>
                            <template x-if="status_col">
                                <td class="px-4 py-3" title="<?php echo e($requirement->status); ?>"><?php echo e($requirement->status ?? ''); ?></td>
                            </template>
                            <template x-if="created_date_col">
                                <td class="px-4 py-3"><?php echo e($requirement->created_at->format('d M Y')); ?></td>
                            </template>
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div class="flex items-center justify-center space-x-1">
                                    <!-- View Button -->
                                    <a href="<?php echo e(route('requirement.detail', $requirement->id)); ?>" wire:navigate
                                        class="p-1 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 transition-colors"
                                        title="View Details">
                                        <i class="fa-solid fa-eye"></i>
                                    </a>

                                    <!-- Edit Button -->
                                    <button type="button" wire:click="edit(<?php echo e($requirement->id); ?>)"
                                        wire:loading.attr="disabled"
                                        class="p-1 text-green-600 hover:text-green-800 dark:text-green-400 dark:hover:text-green-300 transition-colors cursor-pointer"
                                        title="Edit">
                                        <i wire:loading.remove wire:target="edit(<?php echo e($requirement->id); ?>)"
                                            class="fa-solid fa-pen-to-square"></i>
                                        <span wire:loading wire:target="edit(<?php echo e($requirement->id); ?>)" class="ml-1">
                                            <i class="fa-solid fa-spinner animate-spin"></i>
                                        </span>
                                    </button>

                                    <!-- Delete Button -->
                                    <button type="button" wire:loading.attr="disabled"
                                        wire:target="delete(<?php echo e($requirement->id); ?>)" x-data="{
                                            confirmDelete() {
                                                Swal.fire({
                                                    title: 'Are you sure?',
                                                    text: 'This requirement will be permanently deleted!',
                                                    icon: 'warning',
                                                    showCancelButton: true,
                                                    confirmButtonColor: '#d33',
                                                    cancelButtonColor: '#3085d6',
                                                    confirmButtonText: 'Delete'
                                                }).then((result) => {
                                                    if (result.isConfirmed) {
                                                        $wire.delete(<?php echo e($requirement->id); ?>)
                                                    }
                                                })
                                            }
                                        }"
                                        @click="confirmDelete()"
                                        class="p-1 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 transition-colors"
                                        title="Delete">
                                        <i wire:loading.remove wire:target="delete(<?php echo e($requirement->id); ?>)"
                                            class="fa-solid fa-trash-can"></i>
                                        <span wire:loading wire:target="delete(<?php echo e($requirement->id); ?>)"
                                            class="ml-1">
                                            <i class="fa-solid fa-spinner animate-spin"></i>
                                        </span>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="w-full p-4 text-center" colspan="5">No Records found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-4"><?php echo e($requirements->links()); ?></div>
    </div>


    
    
    <div x-show='columns'>
        <div>

        </div>
    </div>
    
    <div x-show='filter_box'
        class="absolute top-0 left-0 h-screen w-screen flex items-center justify-center bg-gray-900/50">
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg">
            <div class="px-8 py-4 border-b dark:border-gray-600">
                <h4 class="text-lg">Apply filters</h4>
            </div>
            <div class="px-8 py-4 grid md:grid-cols-2 gap-4">
                
                <div class="flex flex-col gap-2 w-full min-w-60">
                    <label>Build</label>
                    <div class="relative">
                        <select wire:model.live='build_id' wire:change='updateModulesList' name="build_id"
                            id="build_id"
                            class="appearance-none px-4 pr-2 py-2 w-full rounded-md border border-gray-200 dark:border-gray-700 dark:bg-gray-900">
                            <option value="">All</option>
                            <?php $__empty_1 = true; $__currentLoopData = $builds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $build): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option wire:key='<?php echo e($build->id); ?>' value="<?php echo e($build->id); ?>">
                                    <?php echo e($build->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </select>
                        <div class="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none">
                            <i @click="open_model = !open_model" wire:loading.remove wire:target='build_id'
                                class="fa-solid fa-angle-down"></i>
                            <i wire:loading wire:target='build_id' class="fa-solid fa-spinner fa-spin"></i>
                        </div>
                    </div>
                </div>

                
                <div class="flex flex-col gap-2">
                    <label>Module</label>
                    <div class="relative">
                        <select wire:model.live='module_id' name="module_id" id="module_id"
                            class="appearance-none px-4 pr-2 py-2 w-full rounded-md border border-gray-200 dark:border-gray-700 dark:bg-gray-900">
                            <option value="">All</option>
                            <?php if(isset($modules)): ?>
                                <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option class="text-white" wire:key='<?php echo e($module->id); ?>'
                                        value="<?php echo e($module->id); ?>"><?php echo e($module->module_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <div class="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none">
                            <i @click="open_model = !open_model" wire:loading.remove wire:target='module_id'
                                class="fa-solid fa-angle-down"></i>
                            <i wire:loading wire:target='module_id' class="fa-solid fa-spinner fa-spin"></i>
                        </div>
                    </div>
                </div>

                
                <div class="flex flex-col gap-2">
                    <label>Status</label>
                    <div class="relative">
                        <select wire:model.live='status' name="status" id="status"
                            class="appearance-none px-4 pr-2 py-2 w-full rounded-md border border-gray-200 dark:border-gray-700 dark:bg-gray-900">
                            <option value="">Select status</option>
                            <option value="Backlog">Backlog</option>
                            <option value="Development">Development</option>
                            <option value="Testing">Testing</option>
                            <option value="Completed">Completed</option>
                            <option value="Ready for Testing">Ready for Testing</option>
                            <option value="Design">Design</option>
                            <option value="To Do">To Do</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Done">Done</option>
                        </select>
                        <div class="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none">
                            <i @click="open_model = !open_model" wire:loading.remove wire:target='module_id'
                                class="fa-solid fa-angle-down"></i>
                            <i wire:loading wire:target='module_id' class="fa-solid fa-spinner fa-spin"></i>
                        </div>
                    </div>
                </div>
                
                <div class="flex flex-col gap-2">
                    <label>Created By</label>
                    <div class="relative">
                        <select wire:model='created_by' name="created_by" id="created_by"
                            class="appearance-none px-4 pr-2 py-2 w-full rounded-md border border-gray-200 dark:border-gray-700 dark:bg-gray-900">
                            <option value="">All</option>
                        </select>
                        <div class="absolute inset-y-0 right-0 flex items-center pr-4 pointer-events-none">
                            <i @click="open_model = !open_model" wire:loading.remove wire:target='module_id'
                                class="fa-solid fa-angle-down"></i>
                            <i wire:loading wire:target='module_id' class="fa-solid fa-spinner fa-spin"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="flex items-center justify-center gap-4 px-4 py-3">
                <button wire:click='clearFilter' class="px-4 py-2 rounded-md bg-red-500 text-gray-100">Clear
                    All</button>
                <button @click='filter_box = false'
                    class="px-4 py-2 rounded-md bg-gray-100 dark:bg-gray-700">Close</button>
            </div>
        </div>
    </div>
</div><?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views\livewire\requirement\data-table.blade.php ENDPATH**/ ?>