<div class="flex flex-col gap-1 w-full <?php echo e($class); ?>">
    <label><?php echo e($label); ?>

        <!--[if BLOCK]><![endif]--><?php if($required): ?>
        <span class="text-red-500">*</span>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </label>
    <textarea wire:model='<?php echo e($model); ?>' name="<?php echo e($model); ?>" id="<?php echo e($model); ?>" rows="<?php echo e($rows); ?>" cols="<?php echo e($cols); ?>" placeholder="<?php echo e($placeholder); ?>"
        class="px-4 py-2 rounded-md border border-gray-200 dark:border-gray-700">
        <?php echo e($slot); ?>

    </textarea>
    <!--[if BLOCK]><![endif]--><?php $__errorArgs = [$model];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-red-500"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views/components/textarea.blade.php ENDPATH**/ ?>