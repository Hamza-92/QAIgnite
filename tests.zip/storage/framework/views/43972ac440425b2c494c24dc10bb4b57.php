<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="dark">

<head>
    <?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</head>

<body
    class="font-sans antialiased min-h-screen min-w-screen text-sm bg-white text-gray-900 bg-white dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700">

    
    <?php if (isset($component)) { $__componentOriginalb98fa9b86933f1317fee586f241b2d18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb98fa9b86933f1317fee586f241b2d18 = $attributes; } ?>
<?php $component = App\View\Components\LoadingSpinner::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('loading-spinner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\LoadingSpinner::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb98fa9b86933f1317fee586f241b2d18)): ?>
<?php $attributes = $__attributesOriginalb98fa9b86933f1317fee586f241b2d18; ?>
<?php unset($__attributesOriginalb98fa9b86933f1317fee586f241b2d18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb98fa9b86933f1317fee586f241b2d18)): ?>
<?php $component = $__componentOriginalb98fa9b86933f1317fee586f241b2d18; ?>
<?php unset($__componentOriginalb98fa9b86933f1317fee586f241b2d18); ?>
<?php endif; ?>

    
    <div class="flex h-screen w-screen overflow-hidden">

        <!-- Sidebar (Fixed but does not overlap content) -->
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('layouts.sidebar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-190219886-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        <!-- Main Content Wrapper -->
        <div class="flex flex-col flex-1 h-screen overflow-hidden">

            <!-- Header (Stays within main content area) -->
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('layouts.header', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-190219886-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <!-- Scrollable Content -->
            <main class="flex-1 overflow-auto">
                <div class="max-w-full">
                    <?php echo e($slot); ?>

                </div>
            </main>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginalafb36adf865af54d1e1d61c1adc535d1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalafb36adf865af54d1e1d61c1adc535d1 = $attributes; } ?>
<?php $component = Masmerise\Toaster\ToasterHub::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toaster-hub'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Masmerise\Toaster\ToasterHub::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalafb36adf865af54d1e1d61c1adc535d1)): ?>
<?php $attributes = $__attributesOriginalafb36adf865af54d1e1d61c1adc535d1; ?>
<?php unset($__attributesOriginalafb36adf865af54d1e1d61c1adc535d1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalafb36adf865af54d1e1d61c1adc535d1)): ?>
<?php $component = $__componentOriginalafb36adf865af54d1e1d61c1adc535d1; ?>
<?php unset($__componentOriginalafb36adf865af54d1e1d61c1adc535d1); ?>
<?php endif; ?>
    <?php app('livewire')->forceAssetInjection(); ?>
<?php echo app('flux')->scripts(); ?>

    <script src="https://kit.fontawesome.com/e7da1d2f0a.js" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>

</html>
<?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views/components/layouts/app/main.blade.php ENDPATH**/ ?>