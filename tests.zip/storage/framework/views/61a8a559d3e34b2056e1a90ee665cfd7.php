<div class="relative flex items-center border rounded-md dark:border-gray-700" title="Click to search">
    <label for="<?php echo e($search); ?>" class="absolute inset-y-0 left-0 flex items-center pl-3 cursor-text">
        <i wire:loading.remove wire:target='<?php echo e($search); ?>' class="fa-solid fa-magnifying-glass text-gray-500"></i>
        <i wire:loading wire:target='<?php echo e($search); ?>' class="fa-solid fa-spinner fa-spin text-gray-500"></i>
    </label>
    <input id="<?php echo e($search); ?>" wire:model.live.debounce.300='<?php echo e($search); ?>'
        class="pl-10 pr-3 py-2 w-full rounded-md text-sm dark:bg-gray-900"
        type="text" placeholder="<?php echo e($placeholder); ?>">
    <span class="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-500">
        <i wire:loading.remove wire:target='<?php echo e($resetMethod); ?>' x-show='$wire.<?php echo e($search); ?>.length > 0' class="fa-solid fa-xmark cursor-pointer"
            wire:click='<?php echo e($resetMethod); ?>'></i>
            <i wire:loading wire:target='<?php echo e($resetMethod); ?>' class="fa-solid fa-spinner fa-spin"></i>
    </span>
</div>
<?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views\components\search-field.blade.php ENDPATH**/ ?>