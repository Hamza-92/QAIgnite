<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['type' => 'info', 'message' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['type' => 'info', 'message' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $styles = [
        'success' => 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100',
        'warning' => 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100',
        'error' => 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100',
        'info' => 'bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100',
    ];

    $icons = [
        'success' => 'fa-solid fa-circle-check',
        'warning' => 'fa-solid fa-triangle-exclamation',
        'error' => 'fa-solid fa-circle-xmark',
        'info' => 'fa-solid fa-circle-info',
    ];
?>

<div
    x-data="{ show: true }"
    x-show="show"
    x-transition.duration.300ms
    class="flex items-start gap-3 p-4 mb-4 text-sm font-medium rounded-md shadow-sm <?php echo e($styles[$type]); ?>"
    role="alert"
>
    <!-- Icon -->
    <i class="<?php echo e($icons[$type]); ?> text-lg mt-0.5 shrink-0"></i>

    <!-- Message -->
    <div class="flex-1">
        <?php echo e($message); ?>

    </div>

    <!-- Dismiss Button -->
    <button type="button" @click="show = false" class="text-inherit hover:opacity-70 cursor-pointer">
        <i class="fa-solid fa-xmark mt-0.5"></i>
    </button>
</div>
<?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views/components/alert.blade.php ENDPATH**/ ?>