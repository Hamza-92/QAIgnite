<!--[if BLOCK]><![endif]--><?php if($current !== null): ?>
<div class="w-full">
    <h4 class="font-medium"><?php echo e($field); ?></h4>
    <div class="mt-1 border dark:border-gray-700 rounded-sm flex flex-col sm:flex-row items-center">
        <div class="flex-1 px-4 py-2">
            <!--[if BLOCK]><![endif]--><?php if(isset($isAttachment) && $isAttachment): ?>
                <!--[if BLOCK]><![endif]--><?php if($previous !== 'None'): ?>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = explode(', ', $previous); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="text-sm text-gray-600 dark:text-gray-400"><?php echo e($file); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                <?php else: ?>
                    <?php echo e($previous); ?>

                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php else: ?>
                <?php echo e($previous ?? 'None'); ?>

            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        <span
            x-data="{ isSmallScreen: window.innerWidth < 640 }"
            x-init="window.addEventListener('resize', () => isSmallScreen = window.innerWidth < 640)"
            :class="isSmallScreen ? 'rotate-90 sm:rotate-0' : ''"
            class="px-4 py-2 border-l sm:border-l sm:border-r border-t sm:border-t-0 dark:border-gray-700">
            <i class="fa-solid fa-arrow-right"></i>
        </span>
        <div class="flex-1 px-4 py-2">
            <!--[if BLOCK]><![endif]--><?php if(isset($isAttachment) && $isAttachment): ?>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = explode(', ', $current); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-sm"><?php echo e($file); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            <?php else: ?>
                <span class="<?php echo e($current === 'None' ? 'text-red-500' : ''); ?>">
                    <?php echo e($current); ?>

                </span>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views/livewire/requirement/partials/version-diff.blade.php ENDPATH**/ ?>