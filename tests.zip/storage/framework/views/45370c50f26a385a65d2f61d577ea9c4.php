<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['class' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['class' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div x-data="{ openModel: false }" @click.outside="openModel = false" @close.stop="openModel = false"
class="flex relative rounded-md bg-blue-500 dark:bg-blue-800 text-white dark:tex-gray-300 text-sm <?php echo e($class); ?>">
<a href="<?php echo e(url('projects?createProject=true')); ?>" wire:navigate
    class="flex gap-2 items-center p-2 px-4 border-r border-gray-300 dark:border-gray-500"><i class="fa-solid fa-plus"></i> New Project</a>
<button @click='openModel = !openModel' class="p-2 px-3"><i class="fa-solid fa-angle-down"></i></button>

<div x-show='openModel' x-transition:enter="transition ease-out duration-200"
    x-transition:enter-start="opacity-0 scale-95" x-transition:enter-end="opacity-100 scale-100"
    x-transition:leave="transition ease-in duration-75" x-transition:leave-start="opacity-100 scale-100"
    x-transition:leave-end="opacity-0 scale-95"
    class="absolute w-full z-50 mt-10 shadow-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-300">
    <div class="flex flex-col">
        
        <a class="flex gap-2 items-center text-sm px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer" href=""><i class="fa-solid fa-plus"></i> Module</a>
        <a class="flex gap-2 items-center text-sm px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer" href=""><i class="fa-solid fa-plus"></i> Build</a>
        <a class="flex gap-2 items-center text-sm px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer" href=""><i class="fa-solid fa-plus"></i> Requirement</a>
        
        
        <a class="flex gap-2 items-center text-sm px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer" href=""><i class="fa-solid fa-plus"></i> Test Scenario</a>
        <a class="flex gap-2 items-center text-sm px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer" href=""><i class="fa-solid fa-plus"></i> Test Case</a>
        <a class="flex gap-2 items-center text-sm px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer" href=""><i class="fa-solid fa-plus"></i> Defect</a>
    </div>
</div>
</div>
<?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views\components\layouts\app\action-buttons.blade.php ENDPATH**/ ?>