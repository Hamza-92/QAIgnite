<div x-data='{showModel: false}' class="bg-white dark:bg-gray-800 rounded-lg border dark:border-gray-700 overflow-hidden">
    <!-- Card Header -->
    <div
        class="flex items-center justify-between px-5 py-4 border-b border-violet-500 dark:border-violet-700 bg-gray-50 dark:bg-gray-700/30">
        <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200 flex items-center gap-2">
            <span class="w-2 h-2 mr-1 bg-violet-500"></span>
            Test Scenarios
        </h3>
        <button type="button" title="Filter Test Scenarios" @click="showModel = true"
            class="p-1.5 rounded-full text-gray-500 hover:text-violet-600 hover:bg-violet-100 dark:hover:bg-gray-600 dark:text-gray-400 dark:hover:text-violet-300 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
                stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
            </svg>
        </button>
    </div>

    <!-- Card Content -->
    <div class="px-5 py-4">
        <a href="<?php echo e(route('test-scenarios')); ?>" title="Test Scenarios" wire:navigate class="block">
            <p
                class="text-3xl font-bold text-gray-900 dark:text-white hover:text-violet-600 dark:hover:text-violet-400 transition-colors mb-1">
                <?php echo e($total_test_scenarios ?? '0'); ?>

            </p>
        </a>
    </div>

    <div x-show="showModel" x-cloak class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/50"
        x-transition:enter="transition ease-out duration-200" x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0">

        <!-- Modal Container -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-md max-h-[90vh] flex flex-col overflow-hidden"
            x-show="showModel" @click.away="showModel = false">

            <!-- Modal Header -->
            <div class="flex items-center justify-between px-6 py-4 border-b dark:border-gray-700">
                <div class="flex items-center gap-3">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-violet-600 dark:text-violet-400"
                        fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                    </svg>
                    <h4 class="text-xl font-semibold text-gray-800 dark:text-gray-200">Filter Test Scenarios</h4>
                </div>
                <button @click="showModel = false"
                    class="p-1 rounded-full text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>

            <!-- Modal Content -->
            <div class="px-6 py-5 space-y-5 overflow-y-auto flex-grow">
                <!-- Build ID -->
                <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Build','model' => 'build_id','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <option value="all">All</option>
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $builds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $build): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option class="truncate" wire:key='<?php echo e($build->id); ?>' value="<?php echo e($build->id); ?>">
                            <?php echo e($build->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <option disabled>No builds available</option>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                <!-- Module -->
                <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Module','model' => 'module_id','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <option value="all">All</option>
                    <!--[if BLOCK]><![endif]--><?php if(isset($modules)): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option class="truncate" wire:key='<?php echo e($module->id); ?>' value="<?php echo e($module->id); ?>">
                                <?php echo e($module->module_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>

                <!-- Requirement -->
                <?php if (isset($component)) { $__componentOriginale4a2cdd64afd84d6de6881f468561926 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale4a2cdd64afd84d6de6881f468561926 = $attributes; } ?>
<?php $component = App\View\Components\SingleSelectBox::resolve(['label' => 'Requirement','model' => 'requirement_id','live' => 'true'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('single-select-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SingleSelectBox::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <option value="all">All</option>
                    <!--[if BLOCK]><![endif]--><?php if(isset($requirements)): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option class="truncate" wire:key='<?php echo e($requirement->id); ?>' value="<?php echo e($requirement->id); ?>">
                                <?php echo e($requirement->requirement_title); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $attributes = $__attributesOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__attributesOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale4a2cdd64afd84d6de6881f468561926)): ?>
<?php $component = $__componentOriginale4a2cdd64afd84d6de6881f468561926; ?>
<?php unset($__componentOriginale4a2cdd64afd84d6de6881f468561926); ?>
<?php endif; ?>
            </div>

            <!-- Modal Footer -->
            <div class="flex justify-between px-6 py-4 border-t dark:border-gray-700 bg-gray-50 dark:bg-gray-700/30">
                <button type="button"
                    @click="$wire.set('build_id', 'all'); $wire.set('module_id', 'all'); $wire.set('requirement_id', 'all')"
                    class="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-violet-600 dark:hover:text-violet-400 transition-colors">
                    Clear Filters
                </button>
                <div class="flex gap-3">
                    <button type="button" @click="showModel = false"
                        class="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-600 hover:bg-gray-200 dark:hover:bg-gray-500 rounded-md transition-colors">
                        Cancel
                    </button>
                    <button type="button" @click="showModel = false"
                        class="px-4 py-2 text-sm font-medium text-white bg-violet-600 hover:bg-violet-700 dark:bg-violet-500 dark:hover:bg-violet-600 rounded-md transition-colors shadow-sm">
                        Apply Filters
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\QA Ignite\App\QAIgnite\resources\views/livewire/components/dashboard/info-card/test-scenario-card.blade.php ENDPATH**/ ?>