<?php

namespace App\Livewire\Components;

use Livewire\Component;

class ActionButtons extends Component
{
    public function render()
    {
        return view('livewire.components.action-buttons');
    }
}
