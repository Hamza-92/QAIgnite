<?php

namespace App\Livewire\TestCycle;

use Livewire\Component;

class TestCycleDetails extends Component
{
    public function render()
    {
        return view('livewire.test-cycle.test-cycle-details');
    }
}
