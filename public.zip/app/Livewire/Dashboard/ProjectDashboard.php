<?php

namespace App\Livewire\Dashboard;

use Livewire\Component;

class ProjectDashboard extends Component
{
    public function render()
    {
        return view('livewire.dashboard.project-dashboard');
    }
}
